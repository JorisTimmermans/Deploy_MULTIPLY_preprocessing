# -*- coding: utf-8 -*-

"""Ingestion function for retrieval from HTTP servers"""

__author__ = "Martin Böttcher, Brockmann Consult GmbH"
__copyright__ = "Copyright 2016, Brockmann Consult GmbH"
__license__ = "For use with Calvalus processing systems"
__version__ = "1.6"
__email__ = "info@brockmann-consult.de"
__status__ = "Production"

# changes in 1.1
# verify method extended to distinguish file types
# changes in 1.2
# offer https instead of http for ingestion from OBPG
# changes in 1.3
# OBPG recently has added a slash to dir names, httpmonitor made robust 
# changes in 1.4
# landsat extension for l7, modis ingestion with modification date
# changes in 1.5
# python3 compatibility using six
# changes in 1.6
# adaptation to changed directory identification in HTML response by OBPG
# reference list added as optional parameter
# changes in 1.7
# basic authentication added as option if password is provided
# option withstructuredhtml added to support wget-like scans for all <a href="..."> entries
    
from six.moves import urllib
import lxml
import lxml.html
import datetime
import time
import subprocess
import pytz
import re
from imonitor import IMonitor
from imonitor import IFile

__author__ = 'boe'

class HttpMonitor(IMonitor):
    timeout=600
    _ref_start = None
    _ref_times = []

    def __init__(self, request, srchost, srcuser, srcpassword, srcroot, srcpattern=None, srccursor=None, destroot=".", destmapping=None, destflatten=False, timemapping=None, destreplace=False, usehttps=False, withmodidate=False, reflist=None, reftime='2002-05-04', withstructuredhtml=True):
        IMonitor.__init__(self, request, srchost, srcuser, srcpassword, srcroot, srcpattern, srccursor, destroot, False, destmapping, destflatten, timemapping, destreplace)
        self._usehttps = usehttps
        self._withmodidate = withmodidate
        self._withstructuredhtml = withstructuredhtml
        if reflist:
            self._ref_start = datetime.datetime.strptime(reftime, '%Y-%m-%d')
            with open(reflist) as ref_file:
                for ref_name in ref_file:
                    if ref_name[0] == '#':
                        continue
                    ref_date = datetime.datetime.strptime(ref_name[1:14], '%Y%j%H%M%S')
                    ref_normalised = self._normalised_datetime(ref_date)
                    if ref_normalised not in self._ref_times:
                        self._ref_times.append(ref_normalised)
            self._ref_times.sort()
        if srcpassword:
            # authentication
            manager = urllib.request.HTTPPasswordMgrWithDefaultRealm()
            manager.add_password(None, 'https://'+srchost+srcroot, srcuser, srcpassword)
            dataAuthHandler = urllib.request.HTTPBasicAuthHandler(manager)
            urllib.request.install_opener(urllib.request.build_opener(dataAuthHandler))

    def ls(self, ifile):
        l = []
        opath = self._output_of(ifile.path)
        url = ('https://' if self._usehttps else 'http://') + self._srchost + self._srcroot + ifile.path
        print(url)
        is_beyond_cursor = self._srccursor is None or not self._srccursor.startswith(opath)
        response = urllib.request.urlopen(url, timeout=self.timeout)
        html = response.read()
        #print(html)
        if not self._withstructuredhtml:
            while True:
                match = re.search('<[aA] [hH][rR][eE][fF]="([^"]*)">([^<]*)</[aA]>(.*)', html)
                if not match:
                    break
                href = match.group(1)
                print(href)
                html = match.group(3)
                pathname = href
                if pathname.endswith('/index.htm') or pathname.endswith('/index.html'):
                    pathname = pathname[:pathname.rfind('index.htm')]
                if pathname.startswith('./'):
                    pathname = pathname[2:]
                if pathname[0] != '/':
                    pathname = ifile.path + pathname
                elif len(self._srcroot) > 1 and pathname.startswith(self._srcroot):
                    pathname = pathname[len(self._srcroot):]
                name = pathname[pathname.rfind('/')+1:]
                opath = self._output_of(pathname)
                if not is_beyond_cursor and self._srccursor.startswith(opath):
                    while len(l) > 0:
                        l.pop()
                    if opath == self._srccursor and self._srccompletion == 'c':
                        continue
                if pathname[-1] == '/':
                    l.append(IFile(pathname))
                elif (not self._pattern or self._pattern.match(name)) and (not self._ref_times or self._is_reftime(name)):
                    match2 = re.search('</td><td[^>]*>([^<]*)</td>', html)
                    l.append(IFile(opath, self._complete_url(pathname), match2.group(1)))
            return l
                
        xhtml = lxml.html.fromstring(html)
        for i in xhtml[1].xpath('//table/tbody/tr[td/a]'):
            #name = i[0][0].text
            #pathname = ifile.path + name
            href = i[0][0].get('href')
            if href[-1] == '/':
                pathname = i[0][0].get('href')[len(self._srcroot):-1]
            else:
                pathname = ifile.path + i[0][0].text
            name = pathname[pathname.rfind('/')+1:]
            #if len(i) < 3 or i[2].text == '-':
            if href[-1] == '/':
                opath = self._output_of(self._set_slash_at_end(pathname))
            elif len(i) >= 2 and self._withmodidate:
                opath = ifile.path + i[1].text.split()[0] + '/' + name
                print('opath=' + opath)
            else:
                opath = self._output_of(pathname)
            #print pathname, opath
#            if not self._srccursor or self._srccursor.startswith(opath) or opath >= self._srccursor[:len(opath)]:
            if not is_beyond_cursor and self._srccursor.startswith(opath):
                while len(l) > 0:
                    l.pop()
                if opath == self._srccursor and self._srccompletion == 'c':
                    continue
            #if len(i) < 3 or i[2].text == '-':
            if href[-1] == '/':
                l.append(IFile(self._set_slash_at_end(pathname)))
            elif (not self._pattern or self._pattern.match(name)) and (not self._ref_times or self._is_reftime(name)):
                l.append(IFile(opath, self._complete_url(href), int(i[2].text)))
        # l.sort()
        return l

    def _set_slash_at_end(self, path):
        return path if path.endswith('/') else (path + '/')

    def _complete_url(self, url):
        if url.startswith('http'):
            return url
        else:
            return ('https://' if self._usehttps else 'http://') + self._srchost + url

    def transfer(self, ifile):
        if ifile in self._history:
            print('skipping ' + ifile.path)
            return
        self.prepare_transfer(ifile)
        response = urllib.request.urlopen(ifile.url, timeout=self.timeout)
        if ifile.size == 0:
            if not 'content-length' in response.headers:
                print('response does not contain binary as expected:')
                print(response.read())
                raise IOError('HTTP response does not contain binary content')
            ifile.size = int(response.headers['Content-Length'])
        pos = 0
        statuspos = (ifile.size / 10 + 8192 - 1) / 8192 * 8192
        try:
            with open(self._destroot + ifile.path, "wb") as file:
                while (True):
                    block = response.read(8192)
                    if len(block) == 0:
                        break
                    file.write(block)
                    pos += len(block)
                    if pos == statuspos:
                        now = datetime.datetime.now(pytz.timezone('UTC'))
                        delta = now - ifile.time
                        seconds = delta.days * 86400 + delta.seconds
                        if seconds > 0:
                            ifile.datarate = int(pos * 8 / 1024 / seconds)
                            self._write_status([ifile], [], [])
            if pos == 0:
                print('no bytes received for file ' + ifile.url)
                raise IOError('no bytes received for file ' + ifile.url)
            self.verify(ifile)
        except Exception as e:
            self._write_status([], [], [ifile])
            raise e
        self.finish_transfer(ifile)

    def verify(self, p):
        time.sleep(10)
        return_code = subprocess.call('ls -l ' + self._destroot + p.path, shell=True)
        if p.path[-4:] == '.bz2':
            return_code = subprocess.call('bunzip2 -t ' + self._destroot + p.path, shell=True)
        elif p.path[-4:] == '.tgz':
            return_code = subprocess.call('tar tf ' + self._destroot + p.path + ' > /dev/null', shell=True)
        else:
            return True
        if return_code == 0:
            print('...done. File is ok.')
            return True
        else:
            print('...error. File is NOT ok and moved to ' + p.path + '_corrupt')
            subprocess.call('rm -f ' + self._destroot + p.path + '_corrupt', shell=True)
            subprocess.call('mv ' + self._destroot + p.path + ' ' + self._destroot + p.path + '_corrupt', shell=True)
            raise IOError("integrity test failed for " + p.path)

    def _normalised_datetime(self, t):
        cycle = int((t - self._ref_start).total_seconds() / datetime.timedelta(16).total_seconds())
        return t - cycle * datetime.timedelta(16)

    def _is_reftime(self, name):
        ref_date = datetime.datetime.strptime(name[1:14], '%Y%j%H%M%S')
        ref_normalised = self._normalised_datetime(ref_date)
        return ref_normalised in self._ref_times
