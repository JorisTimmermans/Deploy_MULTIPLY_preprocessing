import datetime
import time
import subprocess
import pytz
from six.moves import urllib
from imonitor import IMonitor
from imonitor import IFile

__author__ = 'boe'

class ModisRefIMonitor(IMonitor):
    _ref_start = None
    _ref_times = []
    _chunk_size = 64

    def __init__(self, request, srchost, srcuser, srcpassword, srcroot, srcpattern=None, srccursor=None,
                 destroot=".", destmapping=None, destflatten=False, timemapping=None, destreplace=False,
                 usehttps=False, stoptime=None, reflist=None, reftime='2002-05-04'):
        IMonitor.__init__(self, request, srchost, srcuser, srcpassword, srcroot, srcpattern, srccursor,
                          destroot, False, destmapping, destflatten, timemapping, destreplace)
        self._usehttps = usehttps
        self._ref_start = datetime.datetime.strptime(reftime, '%Y-%m-%d')
        with open(reflist) as ref_file:
            for ref_name in ref_file:
                if ref_name[0] == '#':
                    continue
                ref_date = datetime.datetime.strptime(ref_name[1:14], '%Y%j%H%M%S')
                ref_normalised = self._normalised_datetime(ref_date)
                if ref_normalised not in self._ref_times:
                    self._ref_times.append(ref_normalised)
        self._ref_times.sort()
        print('reference times per cycle: ' + str(len(self._ref_times)))
        self._stop_time = datetime.datetime.strptime(stoptime, '%Y-%m-%d') if stoptime else datetime.datetime.now(pytz.timezone('UTC'))

    def _normalised_datetime(self, t):
        cycle = int((t - self._ref_start).total_seconds() / datetime.timedelta(16).total_seconds())
        return t - cycle * datetime.timedelta(16)

    def ls(self, ifile):
        l = []
        if ifile.path == '/':
            d = datetime.datetime.strptime(self._srccursor[:10], '%Y-%m-%d')
        else:
            d = datetime.datetime.strptime(ifile.path[:-1], '%Y-%m-%dT%H:%M:%S')
        while d < self._stop_time and d <= datetime.datetime.utcnow():
            n = self._normalised_datetime(d)
            if n in self._ref_times:
                if self._pattern.pattern[0] == 'V':
                    name = d.strftime(self._pattern.pattern[0] + '%Y%j%H%M00.L1A_SNPP.nc')
                    ifile = IFile(self._output_of(name), ('https://' if self._usehttps else 'http://') + self._srchost + '/' + self._srcroot + '/' + name)
                    l.append(ifile)
                    name = d.strftime(self._pattern.pattern[0] + '%Y%j%H%M00.GEO-M_SNPP.nc')
                    ifile = IFile(self._output_of(name), ('https://' if self._usehttps else 'http://') + self._srchost + '/' + self._srcroot + '/' + name)
                    l.append(ifile)
                else:
                    name = d.strftime((self._pattern.pattern[0] if self._pattern else 'A') + '%Y%j%H%M00.L1A_LAC.bz2')
                    ifile = IFile(self._output_of(name), ('https://' if self._usehttps else 'http://') + self._srchost + '/' + self._srcroot + '/' + name)
                    l.append(ifile)
                if len(l) >= self._chunk_size:
                    d += datetime.timedelta(0,0,0,0,5,0)
                    l.append(IFile(d.strftime('%Y-%m-%dT%H:%M:%S/')))
                    break
            d += datetime.timedelta(0,0,0,0,5,0)
        return l

    def transfer(self, ifile):
        if ifile in self._history:
            print('skipping ' + ifile.path)
            return
        self.prepare_transfer(ifile)
        print(ifile.url)
        response = urllib.request.urlopen(ifile.url)
        ifile.size = int(response.info().getheader('Content-Length'))        
        pos = 0
        statuspos = (ifile.size / 10 + 8192 - 1) / 8192 * 8192
        try:
            with open(self._destroot + ifile.path, "wb") as file:
                while (True):
                    block = response.read(8192)
                    if len(block) == 0:
                        break
                    file.write(block)
                    pos += len(block)
                    if pos == statuspos:
                        now = datetime.datetime.now(pytz.timezone('UTC'))
                        delta = now - ifile.time
                        seconds = delta.days * 86400 + delta.seconds
                        if seconds > 0:
                            ifile.datarate = int(pos * 8 / 1024 / seconds)
                            self._write_status([ifile], [], [])
            self.verify(ifile)
        except Exception as e:
            self._write_status([], [], [ifile])
            raise e
        self.finish_transfer(ifile)

    def verify(self, p):
        time.sleep(10)
        if p.path.endswith('bz2'):
            print('bunzip2 -t ' + self._destroot + p.path)
            return_code = subprocess.call('ls -l ' + self._destroot + p.path, shell=True)
            return_code = subprocess.call('bunzip2 -t ' + self._destroot + p.path, shell=True)
        else:
            print('/usr/bin/ncdump -k ' + self._destroot + p.path)
            return_code = subprocess.call('ls -l ' + self._destroot + p.path, shell=True)
            return_code = subprocess.call('/usr/bin/ncdump -k ' + self._destroot + p.path, shell=True)
        if return_code == 0:
            print('...done. File is ok.')
            return True
        else:
            print('...error. File is NOT ok and moved to ' + p.path + '_corrupt')
            subprocess.call('rm -f ' + self._destroot + p.path + '_corrupt', shell=True)
            subprocess.call('mv ' + self._destroot + p.path + ' ' + self._destroot + p.path + '_corrupt', shell=True)
            raise IOError("bunzip2 test or ncdump test failed for " + p.path)
