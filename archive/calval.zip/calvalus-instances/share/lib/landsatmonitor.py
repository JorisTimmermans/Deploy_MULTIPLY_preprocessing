#!/usr/bin/python
# -*- coding: utf-8 -*-

"""Ingestion function for retrieval from EarthExplorer"""

__author__ = "Martin Böttcher, Brockmann Consult GmbH"
__copyright__ = "Copyright 2016, Brockmann Consult GmbH"
__license__ = "For use with Calvalus processing systems"
__version__ = "1.3"
__email__ = "info@brockmann-consult.de"
__status__ = "Production"

# changes in 1.1
# python3 compatibility using six
# changes in 1.2
# RMonitor counterpart and rule implementation functions moved here from ingestion script
# changes in 1.3
# overridden method fixed to be compatible with pmonitor 1.4

import sys
import os
import math
import datetime
import pytz
import time
from six.moves import urllib
from httpmonitor import HttpMonitor
from imonitor import IFile
from rmonitor import RMonitor

class LandsatIterator(object):
    _stack = []
    def __init__(self, srchost, paths, srccursor, platform):
        self._cycle = 0
        self._cursor = 0
        self._srchost = srchost
        self._platform = platform
        self._srccursor = datetime.datetime.strptime(srccursor, '%Y-%m-%d')
        self._now = datetime.datetime.now()
        self._paths = self._date_path_row_tuples(paths, self._srccursor)
    def __iter__(self):
        return self
    def __next__(self):
        date,path,row = self._next_date_path_row()
        # https://earthexplorer.usgs.gov/download/12267/LE71930262010046ASN00/STANDARD/EE
        jdate = date.strftime('%Y%j')
        ymddir = date.strftime('%Y/%m/%d')
        name = '{0}{1}{2}{3}{4}{5}'.format(self._platform, path, row, jdate, 'LGN', '00')
#        src = 'http://{0}/download/4923/{1}/STANDARD/EE'.format(self._srchost, name)
        src = 'http://{0}/download/{1}/{2}/STANDARD/EE'.format(self._srchost, self._collection_id(), name)
        dest = '/{0}/{1}.tgz'.format(ymddir, name)
        #print("__next__ " + dest)
        return IFile(dest, url=src)
    next = __next__
    def _next_date_path_row(self):
        if len(self._paths) == 0:
            print("stopping for empty paths")
            raise StopIteration
        while True:
            if self._cursor >= len(self._paths):
                self._cycle += 1
                self._cursor = 0
            date,path,row = self._paths[self._cursor]
            self._cursor += 1
            date += datetime.timedelta(self._cycle * 16)
            if date >= self._srccursor:
                break
        if date > self._now:
            self._now = datetime.datetime.now()
            if date > self._now:
                #print("stopping for " + str(date) + " after " + str(self._now))
                raise StopIteration
        return date,path,row
    def _date_path_row_tuples(self, paths, srccursor):
        accu = []
        for path in paths:
            date = self._next_acquisition_time(srccursor, int(path))
            for row in paths[path]:
                accu.append((date, path, row))
        accu.sort()
        return accu
    def _next_acquisition_time(self, date, path):
        if path < 98:
            offset = math.fmod(7 * (path-1) + 5, 16)
        else:
            offset = math.fmod(7 * (path-1) + 5, 16) + 1
        d0 = self._mission_start()
        delta = math.fmod((date-d0).days-offset+1, 16)
        if delta == 0:
            return date
        else:
            return date+datetime.timedelta(16-delta)
    def _collection_id(self):
        if self._platform == 'LC8':
            return '12864'
        if self._platform == 'LE7':
            return '12267'
        raise ValueError('Unknown platform ' + self._platform)
    def _mission_start(self):
        if self._platform == 'LC8':
            return datetime.datetime(2013,5,1)
        if self._platform == 'LE7':
            return datetime.datetime(1999,1,11)
        raise ValueError('Unknown platform ' + self._platform)

class LandsatMonitor(HttpMonitor):
    def __init__(self, request, srchost, srcloginhost, srcuser, srcpassword, srccursor, paths, destroot=".", 
                 timemapping=None, destreplace=False, platform='LC8', stations=['LGN']):
        self._platform = platform
        self._stations = stations
        HttpMonitor.__init__(self, request, srchost, srcuser, srcpassword, 'download/' + self._collection_id(), 
                             srccursor=srccursor, destroot=destroot, timemapping=timemapping,
                             destreplace=destreplace)
        self._srcloginhost = srcloginhost
        self._paths = paths
        self._register_handler()
        self.login()
    def _register_handler(self):
        self._opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor())
        urllib.request.install_opener(self._opener)
    def login(self):
        # get cross-site-request-forgery token
        f = self._opener.open("https://{0}".format(self._srcloginhost))
        data = f.read()
        #print(data)
        f.close()
        #<input type="hidden" name="csrf_token" value="v8BnqQ==" id="csrf_token" />
	#<input type="hidden" name="__ncforminfo" value="8pwCALFL90Sbt5_-HU...=="/>
        p1 = data.find('<input type="hidden" name="csrf_token" value="')
        # check whether we are logged in already, no token is served (but the profile page)
        if p1 < 0:
            #print('using existing session')
            return
        p2 = data.find('"', p1+len('<input type="hidden" name="csrf_token" value="'))
        csrf_token = data[p1+len('<input type="hidden" name="csrf_token" value="'):p2]
        p1 = data.find('<input type="hidden" name="__ncforminfo" value="')
        p2 = data.find('"', p1+len('<input type="hidden" name="__ncforminfo" value="'))
        nc_form_info = data[p1+len('<input type="hidden" name="__ncforminfo" value="'):p2]
        #print(csrf_token)
        #print(nc_form_info)
        # use csrf token in login request
        url = "https://{0}/login".format(self._srcloginhost)
        params = urllib.parse.urlencode(dict(username=self._srcuser,password=self._srcpassword,csrf_token=csrf_token))
        #print(url)
        #print(params)
        f = self._opener.open(url, params)
        data = f.read()
        #print(data)
        f.close()
        if data.find('You must sign in as a registered user to download data')>0 or data.find('Invalid username')>0:
            print("Authentication failed")
            sys.exit(-1)
    def iter(self, srccursor=None):
        if srccursor == None: 
            srccursor = self._srccursor
        self._iterator = LandsatIterator(self._srchost, self._paths, srccursor, self._platform)
        return self._iterator
    def prepare_transfer(self, ifile):
        self.login()
        super(LandsatMonitor, self).prepare_transfer(ifile)
    def transfer(self, ifile):
        ee = None
        for station in self._stations:
            for version in ['00', '01', '02']:
                try:
                    # .tgz
                    ifile.path = ifile.path[:-9] + station + version + ifile.path[-4:]
                    # /STANDARD/EE
                    ifile.url = ifile.url[:-17] + station + version + ifile.url[-12:]
                    super(LandsatMonitor, self).transfer(ifile)
                    return
                except urllib.error.HTTPError as e:
                    if e.code != 500:
                        raise e
                    ee = e
                    continue
        raise ee
    def _collection_id(self):
        if self._platform == 'LC8':
            # return '4923'
            return '12864'
        if self._platform == 'LE7':
            return '12267'
        raise ValueError('Unknown platform ' + self._platform)

class LandsatRMonitor(RMonitor):
    least_recent = None
    
    def __init__(self, request, types, hosts, inputs, logdir, simulation, im, tmpdir, stations, srcroot):
        RMonitor.__init__(self, request=request, types=types, hosts=hosts, inputs=inputs, logdir=logdir, simulation=simulation)
        self.im = im
        self.tmpdir = tmpdir
        self.stations = stations
        self.srcroot = srcroot

    def _is_recent(self, event):
        event_date = datetime.datetime.strptime(event[1:11], '%Y/%m/%d')
        least_recent_date = datetime.datetime.strptime(self.least_recent[1:11], '%Y/%m/%d') if self.least_recent else None
        now = datetime.datetime.now()
        if not least_recent_date or least_recent_date > now - datetime.timedelta(2):
            least_recent_date = now - datetime.timedelta(2)
        return event_date > least_recent_date

    def _finalise_step(self, call, code, command, host, output_paths, outputs):
        with self._mutex:
            self._release_constraint(call, host)
            self._running.pop(command)
            if code == 0:
                self._report.write(command + '\n')
                self._report_and_bind_outputs(outputs, output_paths)
                self._report.flush()
                self._processed += 1
            else:
                if call != "landsatget.py":
                    self._failed.append(command)
                else:
                    name = outputs[0][outputs[0].rfind('/')+1:]
                    event = self.im._ifiles.get(name).path
                    if not self._is_recent(event):
                        self._failed.append(command)
                sys.__stderr__.write('failed {0}\n'.format(command))
            self._check_for_mature_tasks()
    def _observe_step(self, call, inputs, outputs, parameters, code):
        RMonitor._observe_step(self, call, inputs, outputs, parameters, code)
        if call == "landsatget.py":
            if code == 0:
                name = outputs[0][outputs[0].rfind('/')+1:]
                least_recent = self.im._ifiles.get(name).path
            else:
                name = outputs[0][outputs[0].rfind('/')+1:]
                event = self.im.recall(name).path
                if self._is_recent(event):
                    print("revoking recent event " + event)
                    with self._mutex:
                        x = self.current_events.get(event)
                        if x and x > 1:
                            self.current_events[event] = x - 1
                        elif x:
                            self.current_events.pop(event)
                            self._write_status()
                else:
                    print("closing non-recent event " + event)
        
    def initiate(self, p):
        name = p.path[p.path.rfind('/')+1:]
        self.im.memorize(name, p)
        self.trigger(p.path, open_count=1)
        time.sleep(0.01)
        self.wait_for_idle(['landsatget.py', 'hdfsput.py'])

    # /2018/09/17/LC80160522018260LGN00.tgz
    def ingest(self, rm, event):
        name = event[event.rfind('/')+1:]
        ymd = event[event.rfind('/',0,event.rfind('/',0,event.rfind('/',0,event.rfind('/'))))+1:event.rfind('/')]
        local_path = self.tmpdir + '/' + name
        rm.execute('landsatget.py', ["https://" + self.im._srchost + self.srcroot], [local_path], parameters=[self.im._srcuser,self.im._srcloginhost,self.stations if type(self.stations) == str else ','.join(self.stations)])

    def archive(self, rm, tmp_path):
        name = tmp_path[tmp_path.rfind('/')+1:]
        event = self.im._ifiles.get(name).path
        ymd = event[event.rfind('/',0,event.rfind('/',0,event.rfind('/',0,event.rfind('/'))))+1:event.rfind('/')]
        target_path = self.im._destroot + '/' + ymd + '/' + name
        rm.execute('hdfsput.py', [tmp_path], [target_path])

    def finalise(self, rm, event):
        mangled_event = self._path_of(event)[0]
        name = event[event.rfind('/')+1:]
        mangled_name = mangled_event[mangled_event.rfind('/')+1:]
        with open(self.tmpdir + '/' + mangled_name + '.rep') as input:
            line = input.read();
        path,size,rate,time = line.split('\t')
        now = datetime.datetime.now(pytz.timezone('UTC'))
        ifile = self.im.recall(name)
        ifile.datarate = int(rate)
        ifile.size = int(size)
        ifile.time = now - datetime.timedelta(seconds=ifile.datarate * 1024 / ifile.size / 8)
        self.im.finish_transfer(ifile)
        rm.close_trigger(ifile.path)
        os.remove(self.tmpdir + '/' + mangled_name + '.rep')

