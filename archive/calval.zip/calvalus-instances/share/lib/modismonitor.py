# -*- coding: utf-8 -*-

"""Ingestion function for retrieval from OBPG servers"""

__author__ = "Martin Böttcher, Brockmann Consult GmbH"
__copyright__ = "Copyright 2016, Brockmann Consult GmbH"
__license__ = "For use with Calvalus processing systems"
__version__ = "1.1"
__email__ = "info@brockmann-consult.de"
__status__ = "Production"

# changes in 1.1
# derived from modisrefimonitor, extended for separate httpget.py and hdfsput.py calls

import datetime
import time
import subprocess
import sys
import os
import pytz
from six.moves import urllib
from imonitor import IMonitor
from imonitor import IFile
from rmonitor import RMonitor

__author__ = 'boe'

class ModisMonitor(IMonitor):
    _ref_start = None
    _ref_times = []
    _chunk_size = 64
    timeout=600

    def __init__(self, request, srchost, srcuser, srcpassword, srcroot, srcpattern=None, srccursor=None,
                 destroot=".", destmapping=None, destflatten=False, timemapping=None, destreplace=False,
                 usehttps=False, withmodidate=False, stoptime=None, reflist=None, reftime='2002-05-04'):
        IMonitor.__init__(self, request, srchost, srcuser, srcpassword, srcroot, srcpattern, srccursor,
                          destroot, False, destmapping, destflatten, timemapping, destreplace)
        self._usehttps = usehttps
        self._withmodidate = withmodidate
        self._stop_time = datetime.datetime.strptime(stoptime, '%Y-%m-%d') if stoptime else None
        if reflist:
            self._ref_start = datetime.datetime.strptime(reftime, '%Y-%m-%d')
            with open(reflist) as ref_file:
                for ref_name in ref_file:
                    if ref_name[0] == '#':
                        continue
                    ref_date = datetime.datetime.strptime(ref_name[1:14], '%Y%j%H%M%S')
                    ref_normalised = self._normalised_datetime(ref_date)
                    if ref_normalised not in self._ref_times:
                        self._ref_times.append(ref_normalised)
            self._ref_times.sort()
            print('reference times per cycle: ' + str(len(self._ref_times)))

    def _normalised_datetime(self, t):
        cycle = int((t - self._ref_start).total_seconds() / datetime.timedelta(16).total_seconds())
        return t - cycle * datetime.timedelta(16)

    def _is_reftime(self, name):
        ref_date = datetime.datetime.strptime(name[1:14], '%Y%j%H%M%S')
        ref_normalised = self._normalised_datetime(ref_date)
        return ref_normalised in self._ref_times

    def _set_slash_at_end(self, path):
        return path if path.endswith('/') else (path + '/')

    def _complete_url(self, url):
        if url.startswith('http'):
            return url
        else:
            return ('https://' if self._usehttps else 'http://') + self._srchost + url

    def ls(self, ifile):
        if self._ref_times:
            return self.ls_by_ref(ifile)
        else:
            return self.ls_by_search(ifile)
        
    def ls_by_ref(self, ifile):
        l = []
        if ifile.path == '/':
            d = datetime.datetime.strptime(self._srccursor[:10], '%Y-%m-%d')
        else:
            d = datetime.datetime.strptime(ifile.path[:-1], '%Y-%m-%dT%H:%M:%S')
        while (not self._stop_time or d < self._stop_time) and d <= datetime.datetime.utcnow():
            n = self._normalised_datetime(d)
            if n in self._ref_times:
                if self._pattern.pattern[0] == 'V':
                    name = d.strftime(self._pattern.pattern[0] + '%Y%j%H%M00.L1A_SNPP.nc')
                    ifile = IFile(self._output_of(name), ('https://' if self._usehttps else 'http://') + self._srchost + '/' + self._srcroot + '/' + name)
                    l.append(ifile)
                    name = d.strftime(self._pattern.pattern[0] + '%Y%j%H%M00.GEO-M_SNPP.nc')
                    ifile = IFile(self._output_of(name), ('https://' if self._usehttps else 'http://') + self._srchost + '/' + self._srcroot + '/' + name)
                    l.append(ifile)
                else:
                    name = d.strftime((self._pattern.pattern[0] if self._pattern else 'A') + '%Y%j%H%M00.L1A_LAC.bz2')
                    ifile = IFile(self._output_of(name), ('https://' if self._usehttps else 'http://') + self._srchost + '/' + self._srcroot + '/' + name)
                    l.append(ifile)
                if len(l) >= self._chunk_size:
                    d += datetime.timedelta(0,0,0,0,5,0)
                    l.append(IFile(d.strftime('%Y-%m-%dT%H:%M:%S/')))
                    break
            d += datetime.timedelta(0,0,0,0,5,0)
        return l

    def ls_by_search(self, ifile):
        l = []
        opath = self._output_of(ifile.path)
        print ('https://' if self._usehttps else 'http://') + self._srchost + self._srcroot + ifile.path
        is_beyond_cursor = self._srccursor is None or not self._srccursor.startswith(opath)
        response = urllib.request.urlopen(('https://' if self._usehttps else 'http://')
                                   + self._srchost + self._srcroot + ifile.path, timeout=self.timeout)
        html = response.read()
        xhtml = lxml.html.fromstring(html)
        for i in xhtml[1].xpath('//table/tbody/tr[td/a]'):
            #name = i[0][0].text
            #pathname = ifile.path + name
            href = i[0][0].get('href')
            if href[-1] == '/':
                pathname = i[0][0].get('href')[len(self._srcroot):-1]
            else:
                pathname = ifile.path + i[0][0].text
            name = pathname[pathname.rfind('/')+1:]
            #if len(i) < 3 or i[2].text == '-':
            if href[-1] == '/':
                opath = self._output_of(self._set_slash_at_end(pathname))
            elif len(i) >= 2 and self._withmodidate:
                opath = ifile.path + i[1].text.split()[0] + '/' + name
                print('opath=' + opath)
            else:
                opath = self._output_of(pathname)
            #print pathname, opath
#            if not self._srccursor or self._srccursor.startswith(opath) or opath >= self._srccursor[:len(opath)]:
            if not is_beyond_cursor and self._srccursor.startswith(opath):
                while len(l) > 0:
                    l.pop()
                if opath == self._srccursor and self._srccompletion == 'c':
                    continue
            #if len(i) < 3 or i[2].text == '-':
            if href[-1] == '/':
                l.append(IFile(self._set_slash_at_end(pathname)))
            elif (not self._pattern or self._pattern.match(name)) and (not self._ref_times or self._is_reftime(name)):
                l.append(IFile(opath, self._complete_url(href), int(i[2].text)))
        # l.sort()
        return l

    def transfer(self, ifile):
        if ifile in self._history:
            print('skipping ' + ifile.path)
            return
        self.prepare_transfer(ifile)
        print(ifile.url)
        response = urllib.request.urlopen(ifile.url)
        ifile.size = int(response.info().getheader('Content-Length'))        
        pos = 0
        statuspos = (ifile.size / 10 + 8192 - 1) / 8192 * 8192
        try:
            with open(self._destroot + ifile.path, "wb") as file:
                while (True):
                    block = response.read(8192)
                    if len(block) == 0:
                        break
                    file.write(block)
                    pos += len(block)
                    if pos == statuspos:
                        now = datetime.datetime.now(pytz.timezone('UTC'))
                        delta = now - ifile.time
                        seconds = delta.days * 86400 + delta.seconds
                        if seconds > 0:
                            ifile.datarate = int(pos * 8 / 1024 / seconds)
                            self._write_status([ifile], [], [])
            self.verify(ifile)
        except Exception as e:
            self._write_status([], [], [ifile])
            raise e
        self.finish_transfer(ifile)

    def verify(self, p):
        time.sleep(10)
        if p.path.endswith('bz2'):
            print('bunzip2 -t ' + self._destroot + p.path)
            return_code = subprocess.call('ls -l ' + self._destroot + p.path, shell=True)
            return_code = subprocess.call('bunzip2 -t ' + self._destroot + p.path, shell=True)
        else:
            print('/usr/bin/ncdump -k ' + self._destroot + p.path)
            return_code = subprocess.call('ls -l ' + self._destroot + p.path, shell=True)
            return_code = subprocess.call('/usr/bin/ncdump -k ' + self._destroot + p.path, shell=True)
        if return_code == 0:
            print('...done. File is ok.')
            return True
        else:
            print('...error. File is NOT ok and moved to ' + p.path + '_corrupt')
            subprocess.call('rm -f ' + self._destroot + p.path + '_corrupt', shell=True)
            subprocess.call('mv ' + self._destroot + p.path + ' ' + self._destroot + p.path + '_corrupt', shell=True)
            raise IOError("bunzip2 test or ncdump test failed for " + p.path)

class ModisRMonitor(RMonitor):
    least_recent = None
    
    def __init__(self, request, types, hosts, inputs, logdir, simulation, im, tmpdir):
        RMonitor.__init__(self, request=request, types=types, hosts=hosts, inputs=inputs, logdir=logdir, simulation=simulation)
        self.im = im
        self.tmpdir = tmpdir

    def _is_recent(self, event):
        event_date = datetime.datetime.strptime(event[1:11], '%Y/%m/%d')
        least_recent_date = datetime.datetime.strptime(self.least_recent[1:11], '%Y/%m/%d') if self.least_recent else None
        now = datetime.datetime.now()
        if not least_recent_date or least_recent_date > now - datetime.timedelta(2):
            least_recent_date = now - datetime.timedelta(2)
        return event_date > least_recent_date

    def _finalise_step(self, call, code, command, host, output_paths, outputs):
        with self._mutex:
            self._release_constraint(call, host)
            self._running.pop(command)
            if code == 0:
                self._report.write(command + '\n')
                self._report_and_bind_outputs(outputs, output_paths)
                self._report.flush()
                self._processed += 1
            else:
                if call != "httpget.py":
                    self._failed.append(command)
                else:
                    name = outputs[0][outputs[0].rfind('/')+1:]
                    event = self.im._ifiles.get(name).path
                    if not self._is_recent(event):
                        self._failed.append(command)
                sys.__stderr__.write('failed {0}\n'.format(command))
            self._check_for_mature_tasks()

    def _observe_step(self, call, inputs, outputs, parameters, code):
        RMonitor._observe_step(self, call, inputs, outputs, parameters, code)
        if call == "httpget.py":
            if code == 0:
                name = outputs[0][outputs[0].rfind('/')+1:]
                least_recent = self.im._ifiles.get(name).path
            else:
                name = outputs[0][outputs[0].rfind('/')+1:]
                event = self.im.recall(name).path
                if self._is_recent(event):
                    print("revoking recent event " + event)
                    with self._mutex:
                        self._unmark_outputs(outputs)
                        x = self.current_events.get(event)
                        if x and x > 1:
                            self.current_events[event] = x - 1
                        elif x:
                            self.current_events.pop(event)
                            self._write_status()
                else:
                    print("closing non-recent event " + event)

    def _unmark_outputs(self, outputs):
        for o in outputs:
            if o in self._counts:
                n = self._counts[o]
                if n <= 1:
                    self._counts.pop(o)
                else:
                    self._counts[o] = n - 1
                
    def initiate(self, p):
        name = p.path[p.path.rfind('/')+1:]
        self.im.memorize(name, p)
        self.trigger(p.path, open_count=1)
        time.sleep(0.01)
        self.wait_for_idle(['httpget.py', 'hdfsput.py'])

    # /2018/09/02/T2018245110000.L1A_LAC.bz2
    def ingest(self, rm, event):
        name = event[event.rfind('/')+1:]
        ymd = event[event.rfind('/',0,event.rfind('/',0,event.rfind('/',0,event.rfind('/'))))+1:event.rfind('/')]
        local_path = self.tmpdir + '/' + name
        rm.execute('httpget.py', ["https://" + self.im._srchost + self.im._srcroot], [local_path])

    def archive(self, rm, tmp_path):
        name = tmp_path[tmp_path.rfind('/')+1:]
        event = self.im._ifiles.get(name).path
        ymd = event[event.rfind('/',0,event.rfind('/',0,event.rfind('/',0,event.rfind('/'))))+1:event.rfind('/')]
        local_path = self.tmpdir + '/' + name
        target_path = self.im._destroot + '/' + ymd + '/' + name
        rm.execute('hdfsput.py', [tmp_path], [target_path])

    def finalise(self, rm, event):
        name = event[event.rfind('/')+1:]
        with open(self.tmpdir + '/' + name + '.rep') as input:
            line = input.read();
        path,size,rate,time = line.split('\t')
        now = datetime.datetime.now(pytz.timezone('UTC'))
        ifile = self.im.recall(name)
        ifile.datarate = int(rate)
        ifile.size = int(size)
        ifile.time = now - datetime.timedelta(seconds=ifile.datarate * 1024 / ifile.size / 8)
        self.im.finish_transfer(ifile)
        rm.close_trigger(ifile.path)
        os.remove(self.tmpdir + '/' + name + '.rep')
