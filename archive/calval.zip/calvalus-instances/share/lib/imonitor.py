# -*- coding: utf-8 -*-

"""Workflow engine base class for ingestion tools"""

__author__ = "Martin Böttcher, Brockmann Consult GmbH"
__copyright__ = "Copyright 2016, Brockmann Consult GmbH"
__license__ = "For use with Calvalus processing systems"
__version__ = "1.5"
__email__ = "info@brockmann-consult.de"
__status__ = "Production"

# changes in 1.1:
# loop added to imonitor as generic solution, memo for open IFiles added
# changes in 1.2
# python3 compatibility
# changes in 1.3
# restrict patching stack in loop to cases where cursor is date, not path
# changes in 1.4
# retry_period and nomore_period added to loop parameters
# changes in 1.5
# robustness against unavailability of data source fixed in loop

import glob
import re
import os
import pytz
import datetime
import time
import traceback
import sys

class IFile(object):
    """
    Representation of an input file or directory with (target) path, source url or path, size, ingestion timestamp, and transfer data rate.
    Implements comparison functions by comparing path only.
    """
    def __init__(self, path, url=None, size=0, time=None, datarate=0):
        self.path = path
        self.url = url
        self.size = size
        self.time = time
        self.datarate = datarate
    def __hash__(self):
        return hash(self.path)
    def __eq__(self, other):
        return self.path == other.path
    def __ne__(self, other):
        return self.path != other.path
    def __lt__(self, other):
        return self.path < other.path
    def __le__(self, other):
        return self.path <= other.path
    def __gt__(self, other):
        return self.path > other.path
    def __ge__(self, other):
        return self.path >= other.path
    def __cmp__(self, other):
        if self.path < other.path:
            return -1
        elif self.path > other.path:
            return 1
        else:
            return 0

class IIterator(object):
    """
    Iterator for the directory tree of an IMonitor that provides a file of the tree with each call to next().
    Uses the ls() function of the IMonitor to convert one directory content to IFile entries.
    Holds an internal stack of IFile, with files and directory entries mixed. Directories are expanded by ls() when required.
    """
    def __init__(self, imonitor):
        self._imonitor = imonitor
        self._stack = [IFile('/')]

    def __iter__(self):
        return self

    def __next__(self):
        while self._stack:
            cursor = self._stack.pop();
            if self._imonitor.is_file(cursor):
                return cursor
            l = self._imonitor.ls(cursor)
            l.reverse()
            self._stack.extend(l)
        raise StopIteration

    next = __next__

class IMonitor(object):
    _utc = pytz.timezone('UTC')

    def __init__(self, request, srchost, srcuser, srcpassword, srcroot, srcpattern=None, srccursor=None, destroot=".", srcremove=False, destmapping=None, destflatten=False, timemapping=None, destreplace=False):
        self._request = request
        self._srchost = srchost
        self._srcroot = srcroot
        if srcpattern:
            self._pattern = re.compile(srcpattern)
        else:
            self._pattern = None
        self._srcuser = srcuser
        self._srcpassword = srcpassword
        self._srccursor = srccursor
        self._srccompletion = 'r'
        self._destroot = destroot
        self._destmapping = destmapping
        self._destflatten = destflatten
        # ('/(..../...)(.*)', '\\1', '%Y/%j', '/%Y/%m/%d\\2')
        if timemapping:
            self._ipattern = re.compile(timemapping[0])
            self._itime_element = timemapping[1]
            self._itime_format = timemapping[2]
            self._otemplate = timemapping[3]
        else:
            self._ipattern = None
        self._srcremove = srcremove
        self._destreplace = destreplace
        self._nofilestransferred = 0
        self._history = []
        self._failed = []
        self._iterator = None
        self._status = open(request + '.status', 'w')
        self._maybe_read_report()
        self._write_status([], [], [])
        self._ifiles = {}

    def ls(self, path):
        raise NotImplementedError

    def transfer(self, ifile):
        raise NotImplementedError

    def _maybe_read_report(self):
        if glob.glob(self._request + '.report'):
            self._report = open(self._request + '.report', 'r+')
            last = None
            now = datetime.datetime.now(self._utc)
            yesterday = datetime.datetime(now.year, now.month, now.day, 0, 0, 0, 0, self._utc) - datetime.timedelta(1)
            print(yesterday)
            for line in self._report.readlines():
                elements = line[:-1].split('\t')
                ifile = IFile(elements[0], None, int(elements[1]), self._utc.localize(datetime.datetime.strptime(elements[3], '%Y-%m-%dT%H:%M:%SZ')), int(elements[2]))
                self._history.append(ifile)
                self._nofilestransferred += 1
                last = ifile.path
            if last > self._srccursor:
                self._srccursor = last
                self._srccompletion = 'c'
        else:
            self._report = open(self._request + '.report', 'w')

    def _write_status(self, retrieving, completed, failed):
        if self._iterator:
            backlog = len([x for x in self._iterator._stack if self.is_file(x)])
            backlogdirs = len(self._iterator._stack) - backlog
        else:
            backlog = 0
            backlogdirs = 0
        #
        now = datetime.datetime.now(self._utc)
        today = datetime.datetime(now.year, now.month, now.day, 0, 0, 0, 0, self._utc)
        yesterday = today - datetime.timedelta(1)
        (nofilestoday, bytestoday, dataratetoday) = self._statisticsof(lambda t: t >= today)
        (nofilesyesterday, bytesyesterday, datarateyesterday) = self._statisticsof(lambda t: t >= yesterday and t < today)
#        if len(self._history) > nofilesyesterday + nofilestoday:
#            self._history[:-nofilestoday-nofilestoday] = []
        #
        self._status.seek(0)
        self._status.write('{0} retrieved, {1} retrieving, {2} failed, {3} backlog, {4} backlogdirs\n'.\
        format(self._nofilestransferred, len(retrieving), len(failed), backlog, backlogdirs))
        self._status.write('{0} files/{1} MB/{2} kbps today, {3} files/{4} MB/{5} kbps yesterday\n'.\
        format(nofilestoday, str(bytestoday/1024/1024), str(dataratetoday),
               nofilesyesterday, str(bytesyesterday/1024/1024), str(datarateyesterday)))
        for l in retrieving:
            if l.datarate > 0:
                self._status.write('c {0}\t{1}\t{2}\n'.format(l.path, str(l.size), str(l.datarate)))
            else:
                self._status.write('r {0}\t{1}\n'.format(l.path, str(l.size)))
        for l in failed:
            self._status.write('f {0}\n'.format(l.path))
        for l in self._failed:
            self._status.write('f {0}\n'.format(l.path))
        for l in completed:
            self._status.write('c {0}\t{1}\t{2}\n'.format(l.path, str(l.size), str(l.datarate)))
        self._status.truncate()
        self._status.flush()

    def _statisticsof(self, istimewithininterval):
        nofiles = 0
        bytes = 0
        transfertime = 0
        for i in self._history:
            if istimewithininterval(i.time):
                nofiles += 1
                bytes += i.size
                if i.datarate > 0:
                    transfertime += i.size * 8 / i.datarate / 1024
        if transfertime > 0:
            datarate = int(bytes * 8 / 1024 / transfertime)
        else:
            datarate = 0
        return (nofiles, bytes, datarate)

    def iter(self, srccursor='donotreset'):
        if srccursor != 'donotreset':
            self._srccursor = srccursor
            self._srccompletion = 'r'
            self._failed = []
        self._iterator = IIterator(self)
        return self._iterator

    def is_file(self, ifile):
        return not ifile.path.endswith('/')

    def prepare_transfer(self, ifile):
        print('transferring {} from {} to {}'.format(ifile.path, self._srcroot, self._destroot))
        self._srccursor = ifile.path
        self._srccompletion = 'r'
        ifile.time = datetime.datetime.now(self._utc)
        self._write_status([ifile], [], [])
        if not os.path.exists(self._destroot + ifile.path[:ifile.path.rfind('/')]) and not ifile.path.rfind('/') == -1:
            os.makedirs(self._destroot + ifile.path[:ifile.path.rfind('/')])
        if os.path.exists(self._destroot + ifile.path) and self._destreplace:
            os.remove(self._destroot + ifile.path)

    def finish_transfer(self, ifile):
        self._srccompletion = 'c'
        now = datetime.datetime.now(self._utc)
        delta = now - ifile.time
        seconds = delta.days * 86400 + delta.seconds
        if seconds > 0:
            ifile.datarate = int(ifile.size * 8 / 1024 / seconds)
        ifile.time = now
        self._history.append(ifile)
        self._report.write(ifile.path + '\t' + str(ifile.size) + '\t' + str(ifile.datarate) + '\t' + ifile.time.strftime('%Y-%m-%dT%H:%M:%SZ') + '\n')
        self._report.flush()
        self._nofilestransferred += 1
        self._write_status([], [ifile], [])
        print('{} transferred'.format(ifile.path))

    def _output_of(self, ipath):
        """
        '/' becomes '/'
        '/Lake_Garda' becomes '/Lake-Garda'
        '/Lake_Garda/LC8001.tar.gz' becomes '/Lake-Garda/LC8001.tar.gz'
        '/Lake_Garda/usecase7/2013/LC8002.tar.gz' becomes '/Lake-Garda/LC8002.tar.gz'
        """
        if self._destmapping:
            for (pattern,name) in self._destmapping:
                m = re.match(pattern, ipath[1:])
                if m:
                    if self._destflatten:
                        return '/' + name + '/' + ipath[ipath.rfind('/')+1:]
                    else:
                        return '/' + name + ipath[m.end():]
        elif self._ipattern:
            # ('/(..../...)(.*)', '\\1', '%Y/%j', '/%Y/%m/%d\\2')
            m = re.match(self._ipattern, ipath)
            if m:
                t = datetime.datetime.strptime(m.expand(self._itime_element), self._itime_format)
                return datetime.datetime.strftime(t, m.expand(self._otemplate))
        return ipath

    def loop(self, handle_ifile, srccursor, srcend=None, retry_period=60, nomore_period=600):
        if srccursor:
            i = self.iter(srccursor)
            if srccursor[0] != '/':
                i._stack = [IFile(srccursor)]
        else:
            i = self.iter()
        p = None
        c = 0
        while True:
            try:
                if p is None:
                    p = next(i)
                    if srcend and p.path >= srcend:
                        print(srcend + ' reached')
                        sys.exit(0)
                    if p in self._history:
                        print('skipping {}'.format(p.path))
                        p = None
                        continue
                    c = 0
                handle_ifile(p)
                p = None
            except SystemExit:
                print('imonitor finished')
                raise
            except StopIteration:
                print('No more files found. sleeping ...')
                time.sleep(nomore_period)
                i = self.iter()
            except Exception as e:
                traceback.print_exc(file=sys.stdout)
                c += 1
                print("I/O error transferring {} cycle {}: {}. sleeping ...".format(p, c, repr(e)))
                time.sleep(retry_period)
                if c >= 5:
                    c = 0
                    if srccursor:
                        p = None
                    else:
                        i = self.iter()

    def memorize(self, name, ifile):
        self._ifiles[name] = ifile

    def recall(self, name):
        return self._ifiles.pop(name)
