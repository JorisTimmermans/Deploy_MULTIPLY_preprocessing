# -*- coding: utf-8 -*-

"""Subscription to DeletedProducts at odata interface of ESA DHuS servers"""

__author__ = "Martin Böttcher, Brockmann Consult GmbH"
__copyright__ = "Copyright 2019, Brockmann Consult GmbH"
__license__ = "For use with Calvalus processing systems"
__version__ = "1.0"
__email__ = "info@brockmann-consult.de"
__status__ = "Production"

# changes in 1.1
# 

import datetime
import traceback
import sys
from lxml import etree
from six.moves import urllib
import six
from imonitor import IMonitor
from imonitor import IFile

class OdataMonitor(IMonitor):
#    _timeout=600
    _timeout=None
    _chunksize=10
    _largeresultthreshold=100
    _cookie = None
    _namespaces = { 'a' : 'http://www.w3.org/2005/Atom',
                    'o' : 'http://a9.com/-/spec/opensearch/1.1/',
                    'm' : 'http://schemas.microsoft.com/ado/2007/08/dataservices/metadata',
                    'd' : 'http://schemas.microsoft.com/ado/2007/08/dataservices'}

    def __init__(self, request, srchost, srcuser, srcpassword, srcroot, protocol="https", product_type="MSIL1C", srccursor=None, initialstep=10, largeresultthreshold=100):
        IMonitor.__init__(self, request, srchost, srcuser, srcpassword, srcroot, None, srccursor)
        self._product_type = product_type
        self._initial_step = initialstep
        self._largeresultthreshold = largeresultthreshold
        self._protocol = protocol
        # authentication
        dataAuthHandler = urllib.request.HTTPBasicAuthHandler(urllib.request.HTTPPasswordMgrWithDefaultRealm())
        dataAuthHandler.add_password(realm=None,  # was: 'OData service',
                                     uri=self._protocol + '://'+srchost+srcroot, user=srcuser, passwd=srcpassword)
        urllib.request.install_opener(urllib.request.build_opener(dataAuthHandler))

    def ls(self, ifile):
        accu = []
        now = self._format_date(datetime.datetime.utcnow())
        # distinguish initial query ...
        if ifile.path == '/':
#            if len(self._history) > 0:
#                begin = self._ingestion_date_of(self._history[-1].path[self._history[-1].path.rfind('/')+1:])
#            else:
#                begin = self._srccursor[:-1]
            begin = self._srccursor[:-1]
            for i in range(-1, -len(self._history)-1, -1):
                try:
                    begin = self._ingestion_date_of(self._history[i].path[self._history[i].path.rfind('/')+1:])
                    break
                except (urllib.error.HTTPError) as e:
                    print('{} retrieval of ingestion date failed: {}'.format(self._history[i].path[self._history[i].path.rfind('/')+1:], str(e)))
                    raise e
                except (Exception) as e:
                    traceback.print_exc(file=sys.stdout)
                    print('{} no longer available, using previous product as cursor'.format(self._history[i].path[self._history[i].path.rfind('/')+1:]))
        # ... and subsequent query, ifile.path=prevDate/ e.g. 2015-09-08T00:00:00.000Z/
        else:
            begin = ifile.path[:-1]
        # determine end of interval by adding repeat cycle
        end = self._format_date(self._date_of(begin) + datetime.timedelta(self._initial_step))
        # loop in case end must be reduced to avoid too big result set
        search_state = 'initial'
        while True:
            # do queries for all areas before sorting all by deletion date
            row = 0
            size = 1
            # do query in chunks
            while row < size:
                size = self._search(begin, end, str(row), self._chunksize, accu)
                row += self._chunksize
                # redo with reduced end if a query returns too large result
                if size > self._largeresultthreshold and end > begin and search_state != 'too_small':
                    search_state = 'too_big'
                    break
            # possible search states here:
            # too big -> redo with shorter time interval
            # retrying and accu empty -> redo as too small with longer time interval again
            # either initial, or retrying with accu, or too small -> take this as result
            if search_state == 'too_big':
                end=self._format_date(self._date_of(begin) + (self._date_of(end) - self._date_of(begin)) / 2)
                accu=[]
                search_state = 'retrying'
                continue
            if search_state == 'retrying' and not accu:
                search_state = 'too_small'
                end = self._format_date(self._date_of(begin) + (self._date_of(end) - self._date_of(begin)) * 2)
                continue
            break
        accu.sort(key=lambda d_i1: (d_i1[0],d_i1[1].path))
        accu = [d_i[1] for d_i in accu]
        #self._make_unique(accu)
        # initiate next query from end onwards after files of this interval are ingested
        print('ls returns ' + str(len(accu)) + ' entries')
        if end < now:
            accu.append(IFile(end + '/'))
        for i in accu:
            print(i.path)
        return accu

    def _make_unique(self, accu):
        for i in range(len(accu)-1,0,-1):
            if accu[i].url == accu[i-1].url:
                accu.pop(i)

    def _search(self, begin, end, row, chunksize, accu):
        try:
            query = None
            xml = None
            type_condition = ("substringof('" + self._product_type + "',Name)") \
                             if isinstance(self._product_type, six.string_types) \
                             else ("(" + " or ".join(["substringof('" + type + "',Name)" for type in self._product_type]) + ")")
            query = self._protocol + '://'+self._srchost+self._srcroot + \
                    "?$filter=" + type_condition + \
                    " and substringof('Invalid',DeletionCause)" + \
                    " and DeletionDate ge datetime'"+ begin.strip('Z') + "'" + \
                    " and DeletionDate lt datetime'" + end.strip('Z') + "'" + \
                    "&$select=Name,DeletionDate,DeletionCause,Size&$skip=" + str(row) + "&$top=" + str(chunksize)
            query = query.replace(' ', '%20').replace("'", "%27")
            print(query)
            # response = self._urlopen(query, context=self._ctx)
            response = self._urlopen(query)
            xml = response.read()
            #print(xml)
            dom = etree.fromstring(xml)
            #hits = int(dom.xpath('/a:feed/o:totalResults', namespaces=self._namespaces)[0].text)
            #print('hits=' + str(hits))
            hits = 0
            for i in dom.xpath('/a:feed/a:entry',namespaces=self._namespaces):
                #name = i.xpath('a:title',namespaces=self._namespaces)[0].text
                name = i.xpath('a:content/m:properties/d:Name',namespaces=self._namespaces)[0].text
                cause = i.xpath('a:content/m:properties/d:DeletionCause',namespaces=self._namespaces)[0].text
                date = i.xpath('a:content/m:properties/d:DeletionDate',namespaces=self._namespaces)[0].text
                size = i.xpath('a:content/m:properties/d:Size',namespaces=self._namespaces)[0].text
                #print((name, cause, size))
                #opath = ('/' + name)
                accu.append((date, IFile(name, cause, int(size))))
                hits += 1
            return hits
        except:
            print("search error:", sys.exc_info()[0])
            print("query: " + str(query))
            print("response: " + str(xml))
            raise

    def _ingestion_date_of(self, name):
        url = self._protocol + '://' + self._srchost + self._srcroot + '?$select=DeletionDate&$filter=substringof(\'' + name + '\',Name)'
        print(url)
        response = self._urlopen(url, timeout=self._timeout)
        xml = response.read()
        #print(xml)
        dom = etree.fromstring(xml)
        return dom.xpath('/a:feed/a:entry/a:content/m:properties/d:DeletionDate', namespaces=self._namespaces)[0].text + 'Z'

    def _urlopen(self, url_string, timeout=None):
        if self._cookie != None:
            # use session cookie from previous calls ...
            url = urllib.request.Request(url_string)
            url.add_header('cookie', self._cookie)
            try:
                response = urllib.request.urlopen(url, timeout=timeout)
                return response
            except urllib.error.HTTPError as e:
                print('old session cookie ' + str(self._cookie) + ' timed out?')
                self._cookie = None
        # ask for new cookie with string url without cookie ...
        response = urllib.request.urlopen(url_string, timeout=timeout)
        self._cookie = response.headers.get('Set-Cookie')
        print('cookie=' + str(self._cookie))
        return response

    def _date_of(self, str):
        return datetime.datetime.strptime(str, '%Y-%m-%dT%H:%M:%S.%fZ')

    def _format_date(self, date):
        return date.strftime('%Y-%m-%dT%H:%M:%S.%fZ')[:-4]+'Z'

