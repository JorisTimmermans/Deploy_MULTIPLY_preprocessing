# -*- coding: utf-8 -*-

"""Ingestion function for retrieval from ESA DHuS servers"""

__author__ = "Martin Böttcher, Brockmann Consult GmbH"
__copyright__ = "Copyright 2016, Brockmann Consult GmbH"
__license__ = "For use with Calvalus processing systems"
__version__ = "1.7"
__email__ = "info@brockmann-consult.de"
__status__ = "Production"

# changes in 1.1
# renamed from s2monitor
# changes in 1.2
# use default realm instead of guessing it, avoids initial query
# changes in 1.3
# granule IDs as search criterion instead of polygon
# changes in 1.4
# exclude duplicates by sorting by unique url
# changes in 1.5
# python3 compatibility using six
# changes in 1.6
# handle None in query for total count
# changes in 1.7
# tracing of query results reduced to no of hits
# timeout parameter added to queries

import time
import datetime
import pytz
import subprocess
import traceback
import sys
import shutil
from lxml import etree
from six.moves import urllib
from imonitor import IMonitor
from imonitor import IFile

class DhusMonitor(IMonitor):
    _timeout=600
#    _timeout=None
    _chunksize=10
    _largeresultthreshold=200
    _cookie = None
    _areas = None
    _attribute = None
    _namespaces = { 'a' : 'http://www.w3.org/2005/Atom',
                    'o' : 'http://a9.com/-/spec/opensearch/1.1/',
                    'm' : 'http://schemas.microsoft.com/ado/2007/08/dataservices/metadata',
                    'd' : 'http://schemas.microsoft.com/ado/2007/08/dataservices'}

    def __init__(self, request, srchost, srcuser, srcpassword, srcroot, areas, srcpattern=None, srccursor=None,
                 destroot=None, destroots=None, destmapping=None, destflatten=False, timemapping=None, destreplace=False,
                 protocol="https", product_type="S2MSI1C", attribute='ingestiondate', 
                 initialstep=10, largeresultthreshold=100):
        IMonitor.__init__(self, request, srchost, srcuser, srcpassword, srcroot, srcpattern, srccursor,
                          destroot, False, destmapping, destflatten, timemapping, destreplace)
        self._areas = areas
        self._destroots = destroots
        self._product_type = product_type
        self._attribute = attribute
        self._initial_step = initialstep
        self._largeresultthreshold = largeresultthreshold
        self._protocol = protocol
        self._search_base_url = self._protocol + '://'+self._srchost+srcroot.replace('odata/v1/Products', 'search')
        # authentication
        dataAuthHandler = urllib.request.HTTPBasicAuthHandler(urllib.request.HTTPPasswordMgrWithDefaultRealm())
        dataAuthHandler.add_password(realm=None,  # was: 'OData service',
                                     uri=self._protocol + '://'+srchost+srcroot, user=srcuser, passwd=srcpassword)
        dataAuthHandler.add_password(realm=None,
                                     uri=self._search_base_url, user=srcuser, passwd=srcpassword)
        urllib.request.install_opener(urllib.request.build_opener(dataAuthHandler))

    def ls(self, ifile):
        accu = []
        now = self._format_date(datetime.datetime.utcnow())
        # distinguish initial query ...
        if ifile.path == '/':
#            if len(self._history) > 0:
#                begin = self._ingestion_date_of(self._history[-1].path[self._history[-1].path.rfind('/')+1:])
#            else:
#                begin = self._srccursor[:-1]
            begin = self._srccursor[:-1]
            for i in range(-1, -len(self._history)-1, -1):
                try:
                    begin = self._ingestion_date_of(self._history[i].path[self._history[i].path.rfind('/')+1:])
                    break
                except (urllib.error.HTTPError) as e:
                    print('{} retrieval of ingestion date failed: {}'.format(self._history[i].path[self._history[i].path.rfind('/')+1:], str(e)))
                    raise e
                except (Exception) as e:
                    traceback.print_exc(file=sys.stdout)
                    print('{} no longer available, using previous product as cursor'.format(self._history[i].path[self._history[i].path.rfind('/')+1:]))
        # ... and subsequent query, ifile.path=prevDate/ e.g. 2015-09-08T00:00:00.000Z/
        else:
            begin = ifile.path[:-1]
        # determine end of interval by adding repeat cycle
        end = self._format_date(self._date_of(begin) + datetime.timedelta(self._initial_step))
        # loop in case end must be reduced to avoid too big result set
        search_state = 'initial'
        while True:
            # do queries for all areas before sorting all by ingestion date
            for area in list(self._areas.keys()):
                row = 0
                size = 1
                # do query in chunks
                while row < size:
                    size = self._search(begin, end, area, str(row), self._chunksize, accu)
                    row += self._chunksize
                    # redo with reduced end if a query returns too large result
                    if size > self._largeresultthreshold and end > begin and search_state != 'too_small':
                        search_state = 'too_big'
                        break
                # restart for all areas with same end in case result for one is too big
                if search_state == 'too_big':
                    break
            # possible search states here:
            # too big -> redo with shorter time interval
            # retrying and accu empty -> redo as too small with longer time interval again
            # either initial, or retrying with accu, or too small -> take this as result
            if search_state == 'too_big':
                end=self._format_date(self._date_of(begin) + (self._date_of(end) - self._date_of(begin)) / 2)
                accu=[]
                search_state = 'retrying'
                continue
            if search_state == 'retrying' and not accu:
                search_state = 'too_small'
                end = self._format_date(self._date_of(begin) + (self._date_of(end) - self._date_of(begin)) * 2)
                continue
            break
        accu.sort(key=lambda d_i1: (d_i1[0],d_i1[1].url))
        accu = [d_i[1] for d_i in accu]
        self._make_unique(accu)
        # initiate next query from end onwards after files of this interval are ingested
        if end < now:
            accu.append(IFile(end + '/'))
        print('ls returns ' + str(len(accu)) + ' entries')
        for i in accu:
            print(i.path)
        return accu

    def _make_unique(self, accu):
        for i in range(len(accu)-1,0,-1):
            if accu[i].url == accu[i-1].url:
                accu.pop(i)

    def transfer(self, ifile):
        if ifile in self._history:
            print('skipping ' + ifile.path)
            return False
        if self._destroots:
            try:
                dir = ifile.path[:ifile.path.rfind('/')]
                day = int(dir[dir.rfind('/')+1:])
                self._destroot = self._destroots[day % len(self._destroots)]
            except:
                print('cannot find day in ' + ifile.path + ' for destroots round robin, using ' + self._destroots[0])
                self._destroot = self._destroots[0]
        elif self._destroot is None:
            self._destroot = '.'
        self.prepare_transfer(ifile)
        if len(self._history) > 0 and self._filename_of(ifile.path) == self._filename_of(self._history[-1].path):
#            print('copying ' + self._history[-1].path + ' to ' + ifile.path)
            print('skipping duplicate ' + self._history[-1].path + ' for ' + ifile.path)
#            try:
#                shutil.copy2(self._destroot + self._history[-1].path, self._destroot + ifile.path)
#            except Exception as e:
#                self._write_status([], [], [ifile])
#                raise e
        else:
            checksum = self._checksum_of(ifile.url)
            # example: https://scihub.esa.int/dhus/odata/v1/Products('33a8c81f-fe4f-4530-ab49-6bd15d2e7403')/$value
            url = self._protocol + '://' + self._srchost + self._srcroot + "('" + ifile.url + "')/$value"
            print('retrieving ' + url)
            response = self._urlopen(url, timeout=self._timeout)
            if ifile.size == 0:
                if not 'content-length' in response.headers:
                    print('response does not contain binary as expected:')
                    print(response.read())
                    raise IOError
                ifile.size = int(response.headers['Content-Length'])
            pos = 0
            statuspos = (ifile.size / 10 + 8192 - 1) / 8192 * 8192
            retry = 0
            try:
                with open(self._destroot + ifile.path, "wb") as file:
                    while (True):
                        block = response.read(8192)
                        if len(block) == 0:
                            retry += 1
                            if pos < ifile.size * 0.98 and retry <= 8:
                                print(self._format_date(datetime.datetime.utcnow()) + ' no more content at ' + str(pos) + '. retrying ' + str(retry))
                                continue
                            break
                        file.write(block)
                        pos += len(block)
                        if pos == statuspos:
                            now = datetime.datetime.now(pytz.timezone('UTC'))
                            delta = now - ifile.time
                            seconds = delta.days * 86400 + delta.seconds
                            if seconds > 0:
                                ifile.datarate = int(pos * 8 / 1024 / seconds)
                                self._write_status([ifile], [], [])
                self.verify(ifile, expected_md5sum=checksum)
            except Exception as e:
                self._write_status([], [], [ifile])
                raise e
        self.finish_transfer(ifile)
        return True

    def verify(self, p, expected_md5sum=None):
        time.sleep(10)
        if expected_md5sum:
            file_md5sum = subprocess.check_output(['/usr/bin/md5sum', self._destroot + p.path]).split()[0].decode()
            print('md5sum is ' + file_md5sum)
            return_code = 0 if file_md5sum == expected_md5sum else 1
        else:
            return_code = subprocess.call('unzip -t ' + self._destroot + p.path, shell=True)
        if return_code == 0:
            print('...done. File is ok.')
            return True
        else:
            print('...error. File is NOT ok and moved to ' + p.path + '_corrupt')
            subprocess.call('rm -f ' + self._destroot + p.path + '_corrupt', shell=True)
            subprocess.call('mv ' + self._destroot + p.path + ' ' + self._destroot + p.path + '_corrupt', shell=True)
            raise IOError(("md5sum" if expected_md5sum else "unzip") + " test failed for " + p.path)

    def _area_condition_of(self, area):
        if not self._areas[area]:
            return ''
        if self._areas[area].startswith('POLYGON') or self._areas[area].startswith('POINT') or self._areas[area].startswith('MULTIPOINT'):
            return ' AND footprint:"Intersects(' + self._areas[area] +  ')"'
        granules = self._areas[area].split(',')
        if len(granules) == 1:
            return ' AND filename:*' + granules[0] + '*'
        condition = ' AND (filename:*' + granules[0] + '*'
        for granule in granules[1:]:
            condition = condition + ' OR filename:*' + granule + '*'
        return condition + ')'
        
    def _search(self, begin, end, area, row, chunksize, accu):
        try:
            query = None
            xml = None
            query = self._search_base_url + '?q=' + self._product_type + ' AND ' + self._attribute + ':[' + begin + ' TO ' + end + ']' + self._area_condition_of(area) + '&rows=' + str(chunksize) + '&start=' + str(row)
            query = query.replace(' ', '%20')
            print(query)
            # response = self._urlopen(query, context=self._ctx)
            response = self._urlopen(query, timeout=self._timeout)
            xml = response.read()
            #print(xml)
            dom = etree.fromstring(xml)
            total_results = dom.xpath('/a:feed/o:totalResults', namespaces=self._namespaces)[0].text
            if total_results is None:
                return 0
            hits = int(total_results)
            print('hits=' + str(hits))
            for i in dom.xpath('/a:feed/a:entry',namespaces=self._namespaces):
                name = i.xpath('a:str[@name="identifier"]',namespaces=self._namespaces)[0].text
                url = i.xpath('a:id',namespaces=self._namespaces)[0].text
                length = i.xpath('a:str[@name="size"]',namespaces=self._namespaces)[0].text
                date = i.xpath('a:date[@name="'+self._attribute+'"]',namespaces=self._namespaces)[0].text
                #print((area, name, url, length, date))
                opath = ('/' + area if self._areas[area] else '') + self._output_of(name)
                if not self._pattern or self._pattern.match(name):
                    accu.append((date, IFile(opath, url, self._size_of(length))))
            return hits
        except:
            print("search error:", sys.exc_info()[0])
            print("query: " + str(query))
            print("response: " + str(xml))
            raise

    def _ingestion_date_of(self, name):
        selector = 'IngestionDate' if self._attribute == 'ingestiondate' else 'ContentDate'
        property = 'd:IngestionDate' if self._attribute == 'ingestiondate' else 'd:ContentDate/d:Start'
        url = self._protocol + '://' + self._srchost + self._srcroot + '?$select='+selector+'&$filter=substringof(\'' + name + '\',Name)'
        print(url)
        response = self._urlopen(url, timeout=self._timeout)
        xml = response.read()
        print(xml)
        dom = etree.fromstring(xml)
        return dom.xpath('/a:feed/a:entry/m:properties/'+property, namespaces=self._namespaces)[0].text + 'Z'

    # md5sum : https://scihub.esa.int/dhus/odata/v1/Products('33a8c81f-fe4f-4530-ab49-6bd15d2e7403')/Checksum
    # <?xml version='1.0' encoding='utf-8'?><Checksum xmlns="http://schemas.microsoft.com/ado/2007/08/dataservices" xmlns:m="http://schemas.microsoft.com/ado/2007/08/dataservices/metadata" m:type="DHuS.Checksum"><Algorithm>MD5</Algorithm><Value>981F9808B85AEFA182F1678529B9F58F</Value></Checksum>
    def _checksum_of(self, uuid):
        url = self._protocol + '://' + self._srchost + self._srcroot + "('" + uuid + "')/Checksum"
        print(url)
        response = self._urlopen(url, timeout=self._timeout)
        xml = response.read()
        print(xml)
        dom = etree.fromstring(xml)
        return dom.xpath('/d:Checksum/d:Value', namespaces=self._namespaces)[0].text.lower()

    def _urlopen(self, url_string, timeout=None):
        if self._cookie != None:
            # use session cookie from previous calls ...
            url = urllib.request.Request(url_string)
            url.add_header('cookie', self._cookie)
            try:
                response = urllib.request.urlopen(url, timeout=timeout)
                return response
            except urllib.error.HTTPError as e:
                print('old session cookie ' + str(self._cookie) + ' timed out?')
                self._cookie = None
        # ask for new cookie with string url without cookie ...
        response = urllib.request.urlopen(url_string, timeout=timeout)
        self._cookie = response.headers.get('Set-Cookie')
        print('cookie=' + str(self._cookie))
        return response

    def _filename_of(self, path):
        return path[path.rfind('/')+1:]

    def _date_of(self, str):
        return datetime.datetime.strptime(str, '%Y-%m-%dT%H:%M:%S.%fZ')

    def _format_date(self, date):
        return date.strftime('%Y-%m-%dT%H:%M:%S.%fZ')[:-4]+'Z'

    def _size_of(self, value_and_unit):
        value,unit = value_and_unit.split()
        if value.startswith('NaN'):
            return 1024 * 1024 * 1024
        if unit == 'GB':
            return int(float(value) * 1024 * 1024 * 1024)
        if unit == 'MB':
            return int(float(value) * 1024 * 1024)
        if unit == 'KB':
            return int(float(value) * 1024)
        else:
            raise Exception('cannot parse value and unit in ' + value_and_unit)

