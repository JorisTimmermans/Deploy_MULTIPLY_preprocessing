# calvalus-instances
Processing system instances of the BC Calvalus
==============================================

 o This repository shall maintain the configurations of all Calvalus
processing system instances on the different hosts master00,
calvalus-production, calvalus-production2, ... .

 o Independence of updates is achived by using different branches for
different instances. One instance is in one branch. The branches are
named like the prefix of the respective instance. Symbolic links in
/home/cvop/xxx-inst point to the directories checked out from
github. Symbolic links from user home directories point to these
links.

 o Nothing except this readme is in the master branch.

 o The lib directory of an instance that contains generic scripts can
be partially or fully replaced by a shared/lib directory that is
checked out separately and made available as symbolic link in
/home/calvalus/shared . shared is maintained in the branch 'shared'.

 o The files and directories in the instances shall be
group-writable. Users commit changes using their personal GitHub
account.

Runtime directory structure
---------------------------

/home/cvop/<root-dir>/<branch-dir>/<repo-dir>/<instance-dir>/...

with root-dir = inst
     branch-dir = <xxx>  (for all different branches/instances)
     repo-dir = calvalus-instances
     instance-dir = <xxx>-inst  (only one in one branch!)

/home/cvop/<instance-dir> -> /home/cvop/<root-dir>/<branch-dir>/<repo-dir>/<instance-dir>
/home/cvop/shared -> /home/cvop/<root-dir>/shared/<repo-dir>/shared

shared/ contains:
  lib/pmonitor.py
  lib/imonitor.py
  lib/pstep.py
  lib/threadpool.py
  lib/httpmonitor.py
  lib/s2monitor.py
  lib/...
  lib/cpt.jar  (manually copied, not in repository!)
  bin/pmps
  bin/pmstartup
  bin/pmshutdown
  bin/submitproductionrequest.sh

<instance-dir>/ usually contains
  my<xxx>
  <xxx>.py
  ...
  bin/<xxx>-step.py
  etc/...-template.xml
  special-requests/....xml
  lib/  (optional, overwriting the versions in shared)

Setting up a new instance
-------------------------

# Precondition: There is a user cvop with home dir /home/cvop on the machine. 
# Precondition: You have a github account and you are collaborator of bcdev's repository calvalus-instances.
# Precondition: There is not yet a branch xxx .

mkdir -p /home/cvop/inst/xxx
cd /home/cvop/inst/xxx
git clone https://github.com/bcdev/calvalus-instances
cd calvalus-instances
git branch xxx
git checkout xxx
mkdir xxx-inst
ln -s $(pwd) xxx-inst/.repo
cd xxx-inst
mkdir etc bin special-requests log requests lib
# ... create content of the instance and 'git add' it
cd .repo
git commit -am 'initial version of xxx-inst'
git push --all
#
cd /home/cvop
ln -s /home/cvop/inst/xxx/calvalus-instances/xxx-inst .
#
cd ~
ln -s /home/cvop/xxx-inst .

Creating an instance from the repository
----------------------------------------

mkdir -p /home/cvop/inst/xxx
cd /home/cvop/inst/xxx
git clone -b xxx https://github.com/bcdev/calvalus-instances
cd calvalus-instances
ln -s $(pwd) xxx-inst/.repo
cd xxx-inst
#
cd /home/cvop
ln -s /home/cvop/inst/xxx/calvalus-instances/xxx-inst .
#
cd ~
ln -s /home/cvop/xxx-inst .

Committing changes to an instance
---------------------------------

cd ~/xxx-inst/.repo
git pull origin xxx
cd ~/xxx-inst
# update some files ...
cd .repo
git commit -am 'fix of ...' xxx-inst
git push origin xxx



